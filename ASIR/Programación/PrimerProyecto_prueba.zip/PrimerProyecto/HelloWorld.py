

a = 'adios'
n_1 = 22
n_2 = 5

print (a)
 #num_client = 0.15 e-3  #notación cientifica




n_3 = (40 - 2*6)/4
print(n_3)
print(True and False)
