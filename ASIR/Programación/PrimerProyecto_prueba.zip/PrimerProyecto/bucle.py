
#a = 0
#b = 1

#while a < 1000:
#    print(a)
#    aux = a
#    a = b
#    b = aux + b



''' continuar = True #Variable auxiliar iteradora

 while continuar:
    equipoFutbol = input("Introduce un equipo de futbol: ")

    if equipoFutbol == "Barca":
        print("Pesima eleccion")
        continuar = False
    elif equipoFutbol == "Real Madrid":
        print("Buena eleccion")
        continuar = False
    elif equipoFutbol == "Atleti":
        print("Mala eleccion")
        continuar = False
    else:
        print("Introduce un equipo de fútbol válido")'''


'''lista_colores = ['rojo', 'verde', 'azul']

for color in lista_colores:
    print(color)

indice_color = 0
while indice_color < 3:
    print(lista_colores[indice_color])
    indice_color+=1'''

num = int(input('introduce un  numero: ')) #numeros primos
primo = True

for i in range(2, num):
    if num%i == 0:
        primo = False

if primo:
    print("El número "+ str(num) +" es primo")
else:
    print("El número "+ str(num) +" no es primo")