
num_max = 10

num_min = 1

num = int(input("Escriba un numero de 1 a 10:"))

#{if num <= num_max:
    #print("Tu numero es:" + str(num))
#elif num >= num_min:
    #print("tu numero es:" + str(num))
#else:
    #print("El numero no cumple la condicion")

if num%2  == 0:
        print("Tu numero es divisible por 2")
if num %3 == 0:
    print("Tu numero es divisible por 3")
if num %5 == 0:
        print("Tu numero es divisible por 5")
else:
        print("El numero no cumple la condicion")
