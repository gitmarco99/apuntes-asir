num = int(input("introduce un numero:"))
if num%2 == 0:
    print ("es divisible por 2")

if num%3 == 0:
    print ("es divisible por 3")

if num%5 == 0:
    print ("es divisible por 5")

else:
    print ("No es divisible por 2,3,5")

