cadena_1 = "hola"
cadena_2 = 'hola'

print(cadena_2 == cadena_1 )

print( cadena_1 + "\n" + cadena_2)

print(r"rico \n adios \" patata")

cadena_larga = '''

En aulas de tiza y de libros abiertos,
florece tu voz como brisa temprana;
Ana María, maestra de versos,
tejías el aire con lengua lejana.

Tus ojos guardaban secretos discretos,
como un río que fluye en silencio,
y al pronunciar “dreams”, “hope” o “eternal”,
se alzaba en los muros un eco sincero.

David, viajero de sombras y horas,
no supo jamás de tu dulce latido,
de aquel corazón que en tardes doradas
susurraba un nombre que nunca fue oído.

Entre pupitres, cuadernos y espejos,
escondiste un mundo callado y profundo,
donde el inglés era puente secreto
que unía tus sueños con todo el mundo.

Oh maestra que amabas callada,
tus días fueron canto sereno,
y aunque nadie leyó tu balada,
quedó en el viento tu verso pequeño.

'''
print(cadena_larga)

print(cadena_1*2)

print (cadena_2*len(cadena_1))

print(cadena_1[1])

print(cadena_1[0])

print(cadena_larga[15])

print(cadena_larga[:41])